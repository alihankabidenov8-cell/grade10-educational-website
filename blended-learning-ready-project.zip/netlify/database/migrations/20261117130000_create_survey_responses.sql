CREATE TABLE IF NOT EXISTS survey_responses (
  id SERIAL PRIMARY KEY,
  answers JSONB NOT NULL,
  feedback TEXT,
  language VARCHAR(8),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
