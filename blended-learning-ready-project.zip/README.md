# Blended Learning — Grade 10 Research Project

Interactive educational website for the research project “Blended Learning: Combining Classroom Lessons with Online Platforms — Is It the Most Effective Way?” by Alikhan Kabidenov (Grade 10 “Б”, MMGI, Abai Region, Kazakhstan, 2026; supervisor Bulanbayev Serik Zhenisbekuly).

## Main website

https://grade10-educational-website.netlify.app

The QR page generates a QR code for the **homepage**. Visitors scan it to open the complete platform, then navigate to lessons, videos, vocabulary, quizzes and the survey.

## Features

- 13 working content routes, including `/survey` and `/qr`
- English, Russian and Kazakh interface
- Eight-question anonymous survey with selectable answers and submit action
- Server API at `/api/survey` to validate and save responses
- Survey dashboard showing totals and answer counts
- QR code PNG download; QR target is the public homepage

## Survey database setup

The survey API uses Drizzle ORM with Netlify Database (`@netlify/database`). The SQL migration is included at `netlify/database/migrations/20261117130000_create_survey_responses.sql`. Netlify Database must be enabled for the site and supported by the site's Netlify plan. Netlify applies committed migrations during deployment. If the database is not provisioned or the migration has not been applied, survey submissions and live statistics will return an error and will not be saved.

Netlify Database setup guide: https://docs.netlify.com/build/data-and-storage/netlify-database/getting-started/

## Build

- Build command: `vite build`
- Publish directory: `dist/client`
- Node version: 24
- Install dependencies with `pnpm install` or `npm install`
- Run locally with `npm run dev`

## Deployment

Connect the GitHub repository to Netlify. Push the project files to the connected branch and wait for a successful Published deploy. After deployment, verify the homepage, `/survey`, `/qr`, and `/api/survey`. Submit one test response and confirm that the total response count increases after refreshing the survey page.
