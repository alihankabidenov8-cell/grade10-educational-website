import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import * as QRCode from 'qrcode'
import { Download, ExternalLink, Printer, QrCode } from 'lucide-react'
import { PageHero } from '@/components/site/page-hero'
import { Button } from '@/components/ui/button'
import { useI18n } from '@/lib/i18n'

const PLATFORM_URL = 'https://grade10-educational-website.netlify.app'

export const Route = createFileRoute('/qr')({ component: QrPage })

function QrPage() {
  const { t, lang } = useI18n()
  const [image, setImage] = React.useState('')
  const [error, setError] = React.useState('')

  React.useEffect(() => {
    QRCode.toDataURL(PLATFORM_URL, {
      width: 640,
      margin: 4,
      errorCorrectionLevel: 'H',
      color: { dark: '#102044', light: '#ffffff' },
    })
      .then(setImage)
      .catch(() => setError('QR generation failed'))
  }, [])

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(PLATFORM_URL)
    } catch {
      setError('Clipboard is not available on this device')
    }
  }

  const text = {
    en: {
      how: 'How to use the platform',
      steps: [
        'Open the camera app on your phone or tablet.',
        'Point it at the QR code and tap the link that appears.',
        'The main page of the Blended Learning platform will open.',
        'Explore the lessons, videos, vocabulary and quiz. Open the Survey section to choose answers and submit your response.',
      ],
      open: 'Open platform',
      download: 'Download QR image',
      copy: 'Copy website link',
      print: 'Print',
    },
    ru: {
      how: 'Как пользоваться платформой',
      steps: [
        'Откройте камеру на телефоне или планшете.',
        'Наведите её на QR-код и нажмите на появившуюся ссылку.',
        'Откроется главная страница платформы «Смешанное обучение».',
        'Изучайте уроки, видео, словарь и тест. Чтобы ответить на вопросы, откройте раздел «Опрос» и отправьте ответы.',
      ],
      open: 'Открыть платформу',
      download: 'Скачать QR-код',
      copy: 'Копировать адрес сайта',
      print: 'Печать',
    },
    kk: {
      how: 'Платформаны пайдалану жолы',
      steps: [
        'Телефонда немесе планшетте камераны ашыңыз.',
        'QR-кодқа бағыттап, пайда болған сілтемені басыңыз.',
        'Аралас оқыту платформасының басты беті ашылады.',
        'Сабақтарды, бейнелерді, сөздікті және тестті қараңыз. Сауалнамаға жауап беру үшін «Сауалнама» бөліміне өтіп, жауаптарды жіберіңіз.',
      ],
      open: 'Платформаны ашу',
      download: 'QR-кодты жүктеу',
      copy: 'Сайт сілтемесін көшіру',
      print: 'Басып шығару',
    },
  }[lang]

  return (
    <>
      <PageHero icon={QrCode} eyebrow={t('common.shortTitle')} title={t('qr.title')} subtitle={t('qr.subtitle')} />
      <section className="mx-auto grid max-w-4xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[minmax(260px,1fr)_1fr]">
        <div className="rounded-3xl border bg-card p-6 text-center">
          <div className="mx-auto aspect-square max-w-[340px] rounded-2xl bg-white p-3">
            {image ? (
              <img
                src={image}
                alt="QR code linking to the Blended Learning educational platform homepage"
                className="size-full"
              />
            ) : (
              <div className="grid size-full place-items-center text-muted-foreground">
                {error || 'Generating QR code…'}
              </div>
            )}
          </div>
          <p className="mt-4 break-all text-xs text-muted-foreground">{PLATFORM_URL}</p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <Button
              disabled={!image}
              onClick={() => {
                const a = document.createElement('a')
                a.href = image
                a.download = 'blended-learning-platform-qr.png'
                a.click()
              }}
            >
              <Download className="mr-2 size-4" />
              {text.download}
            </Button>
            <Button variant="outline" onClick={copy}>
              {text.copy}
            </Button>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer className="mr-2 size-4" />
              {text.print}
            </Button>
          </div>
          {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
        </div>
        <div className="rounded-3xl border bg-card p-6">
          <h2 className="text-xl font-semibold">{text.how}</h2>
          <ol className="mt-5 space-y-4">
            {text.steps.map((step, index) => (
              <li key={step} className="flex gap-3 text-sm leading-relaxed">
                <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                  {index + 1}
                </span>
                {step}
              </li>
            ))}
          </ol>
          <Button asChild className="mt-7 w-full">
            <a href="/">
              {text.open}
              <ExternalLink className="ml-2 size-4" />
            </a>
          </Button>
        </div>
      </section>
    </>
  )
}
