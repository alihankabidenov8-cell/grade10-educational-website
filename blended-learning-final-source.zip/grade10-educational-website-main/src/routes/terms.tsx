import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Blend, Compass, Cpu, Flame, Globe, LayoutDashboard, School, ScrollText, Sparkles, Split, UserRound } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { PageHero } from '@/components/site/page-hero'
import { Reveal } from '@/components/site/reveal'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { TERMS, type Term } from '@/data/terms'

export const Route = createFileRoute('/terms')({
  head: () => ({ meta: [{ title: 'Key Research Terms — Blended Learning' }] }),
  component: TermsPage,
})

const LOCALIZED = {
  ru: [
    ['Образовательный подход, объединяющий очное обучение в классе с онлайн-занятиями. Ученик получает некоторый контроль над временем, местом, маршрутом или темпом обучения.', 'Ученики смотрят короткое видео дома, а затем обсуждают его и вместе решают задачи в классе.'],
    ['Обучение под руководством учителя в обычном классе по расписанию, обычно с объяснениями, учебниками и письменными упражнениями.', 'Учитель объясняет грамматику у доски, а ученики выполняют упражнения в тетрадях.'],
    ['Обучение через интернет с использованием цифровых материалов, видеоуроков, онлайн-тестов и виртуального общения.', 'Ученик проходит онлайн-курс с видеолекциями и автоматически проверяемыми тестами.'],
    ['Умение безопасно и ответственно находить, оценивать, создавать и передавать информацию с помощью цифровых технологий.', 'Перед использованием сайта для проекта ученик проверяет надёжность источника.'],
    ['Степень внимания, любознательности, интереса и активного участия ученика в обучении.', 'Ученики активно отвечают на вопросы интерактивной викторины.'],
    ['Подход, при котором темп, содержание и поддержка адаптируются к потребностям, возможностям и интересам ученика.', 'Онлайн-платформа предлагает дополнительные упражнения по трудной для ученика теме.'],
    ['Программное обеспечение для размещения, организации и отслеживания учебных материалов, заданий, тестов, оценок и общения.', 'Google Classroom и Moodle — примеры систем управления обучением.'],
    ['Использование цифровых инструментов, программ и устройств для поддержки и улучшения преподавания и обучения.', 'Интерактивные доски, учебные приложения и онлайн-тесты относятся к образовательным технологиям.'],
    ['Процесс, в котором ученик самостоятельно отвечает за обучение: ставит цели, ищет ресурсы и оценивает прогресс.', 'Ученик планирует недельное расписание, чтобы повторить лексику до контрольной.'],
    ['Модель, при которой часть учеников присутствует в классе, а часть подключается удалённо, либо обучение чередуется между школой и домом.', 'Половина класса находится в кабинете, а другая половина подключается по видеосвязи.'],
  ],
  kk: [
    ['Сыныптағы дәстүрлі оқытуды онлайн сабақтармен біріктіретін білім беру тәсілі. Оқушы оқу уақытына, орнына, бағытына немесе қарқынына белгілі бір деңгейде ықпал етеді.', 'Оқушылар үйде қысқа бейне көріп, кейін сыныпта оны талқылап, тапсырмаларды бірге орындайды.'],
    ['Белгіленген уақытта сыныпта мұғалімнің жетекшілігімен өтетін, түсіндіру, оқулық және жазбаша жаттығуларға негізделген оқу.', 'Мұғалім тақтада грамматиканы түсіндіреді, ал оқушылар дәптерде жаттығу орындайды.'],
    ['Интернет арқылы цифрлық материалдар, бейнесабақтар, онлайн тесттер және виртуалды байланыс көмегімен оқу.', 'Оқушы бейнедәрістер мен автоматты тексерілетін тесттері бар онлайн курсты өтеді.'],
    ['Цифрлық технологияларды пайдаланып ақпаратты қауіпсіз әрі жауапкершілікпен табу, бағалау, жасау және жеткізу қабілеті.', 'Жобаға сайтты қолданбас бұрын оқушы дереккөздің сенімділігін тексереді.'],
    ['Оқушының оқу кезіндегі зейіні, қызығушылығы және белсенді қатысу деңгейі.', 'Оқушылар интерактивті викторина сұрақтарына белсенді жауап береді.'],
    ['Оқу қарқыны, мазмұны және қолдау әр оқушының қажеттілігі мен қызығушылығына бейімделетін тәсіл.', 'Онлайн платформа оқушыға қиын тақырып бойынша қосымша жаттығулар ұсынады.'],
    ['Оқу материалдарын, тапсырмаларды, тесттерді, бағаларды және қарым-қатынасты ұйымдастырып, бақылауға арналған бағдарламалық жүйе.', 'Google Classroom мен Moodle — оқуды басқару жүйелерінің мысалдары.'],
    ['Оқыту мен білім алуды қолдау және жақсарту үшін цифрлық құралдар мен бағдарламаларды пайдалану.', 'Интерактивті тақта, оқу қосымшалары және онлайн тесттер білім беру технологияларына жатады.'],
    ['Оқушының мақсат қойып, ресурстар тауып, өз жетістігін бағалау арқылы оқуына өзі жауап беретін үдеріс.', 'Оқушы бақылау жұмысына дейін сөздерді қайталау үшін апталық жоспар жасайды.'],
    ['Оқушылардың бір бөлігі сыныпта, ал екінші бөлігі қашықтан қатысатын немесе оқу мектеп пен үй арасында кезектесетін модель.', 'Сыныптың жартысы кабинетте, қалған бөлігі бейнеқоңырау арқылы қосылады.'],
  ],
} as const

const ICONS: Record<Term['icon'], LucideIcon> = {
  blend: Blend,
  school: School,
  globe: Globe,
  cpu: Cpu,
  flame: Flame,
  user: UserRound,
  layout: LayoutDashboard,
  sparkles: Sparkles,
  compass: Compass,
  split: Split,
}

function TermsPage() {
  const { t, lang } = useI18n()
  const [open, setOpen] = React.useState<string | null>(TERMS[0].term)
  return (
    <>
      <PageHero icon={ScrollText} eyebrow={lang === 'ru' ? `${TERMS.length} терминов` : lang === 'kk' ? `${TERMS.length} термин` : `${TERMS.length} terms`} title={t('terms.title')} subtitle={t('terms.subtitle')} />
      <section className="mx-auto max-w-content px-4 py-14 sm:px-6">
        <div className="grid gap-5 md:grid-cols-2">
          {TERMS.map((term, i) => {
            const Icon = ICONS[term.icon]
            const isOpen = open === term.term
            const translation = lang === 'ru' ? term.ru : lang === 'kk' ? term.kk : `${term.ru} · ${term.kk}`
            const localized = lang === 'en' ? [term.definition, term.example] : LOCALIZED[lang][i]
            return (
              <Reveal key={term.term} delay={(i % 2) * 80}>
                <article
                  className={cn(
                    'h-full rounded-3xl border bg-card transition-all duration-300',
                    isOpen ? 'border-primary/50 card-glow' : 'hover:border-primary/30',
                  )}
                >
                  <h2>
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      onClick={() => setOpen(isOpen ? null : term.term)}
                      className="flex w-full items-center gap-4 p-5 text-left sm:p-6"
                    >
                      <span
                        className={cn(
                          'grid size-12 shrink-0 place-items-center rounded-2xl transition-all',
                          isOpen ? 'bg-gradient-to-br from-electric to-cyan text-white shadow-lg' : 'bg-accent text-primary',
                        )}
                      >
                        <Icon className="size-6" aria-hidden />
                      </span>
                      <span className="flex-1">
                        <span className="block font-display text-base font-semibold sm:text-lg">
                          <span className="mr-2 text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
                          {term.term}
                        </span>
                        <span className="mt-0.5 block text-sm text-muted-foreground">{translation}</span>
                      </span>
                      <span className={cn('text-xl text-primary transition-transform', isOpen && 'rotate-45')} aria-hidden>
                        +
                      </span>
                    </button>
                  </h2>
                  <div className={cn('grid transition-all duration-300', isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0')}>
                    <div className="overflow-hidden">
                      <div className="space-y-3 px-5 pb-6 sm:px-6">
                        <p className="leading-relaxed">{localized[0]}</p>
                        <p className="rounded-2xl bg-muted/60 p-3 text-sm text-muted-foreground">
                          <b className="text-foreground">{lang === 'ru' ? 'Пример:' : lang === 'kk' ? 'Мысал:' : 'Example:'}</b> {localized[1]}
                        </p>
                      </div>
                    </div>
                  </div>
                </article>
              </Reveal>
            )
          })}
        </div>
      </section>
    </>
  )
}
