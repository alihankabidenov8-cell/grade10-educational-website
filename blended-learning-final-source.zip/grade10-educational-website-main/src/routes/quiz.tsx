import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Brain, RotateCcw, Trophy } from 'lucide-react'
import { PageHero } from '@/components/site/page-hero'
import { Button } from '@/components/ui/button'
import { useI18n, type L } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/quiz')({ component: QuizPage })

const QUESTIONS: { q: L; options: L[]; answer: number; why: L }[] = [
  { q:{en:'What is blended learning?',ru:'Что такое смешанное обучение?',kk:'Аралас оқыту дегеніміз не?'}, options:[
    {en:'Only online courses',ru:'Только онлайн-курсы',kk:'Тек онлайн курстар'},
    {en:'Classroom teaching combined with online learning',ru:'Сочетание занятий в классе и онлайн-обучения',kk:'Сыныптағы сабақ пен онлайн оқытудың үйлесуі'},
    {en:'Studying without a teacher',ru:'Обучение без учителя',kk:'Мұғалімсіз оқу'},
    {en:'Learning several subjects at once',ru:'Изучение нескольких предметов одновременно',kk:'Бір уақытта бірнеше пәнді оқу'}], answer:1,
    why:{en:'It connects face-to-face teaching with purposeful online activities.',ru:'Оно объединяет очное обучение с целенаправленными онлайн-заданиями.',kk:'Ол бетпе-бет оқытуды мақсатты онлайн тапсырмалармен біріктіреді.'}},
  { q:{en:'What is a flipped classroom?',ru:'Что такое перевёрнутый класс?',kk:'Төңкерілген сынып дегеніміз не?'}, options:[
    {en:'Students study new material at home and practise in class',ru:'Ученики изучают новую тему дома, а в классе практикуются',kk:'Оқушылар жаңа материалды үйде оқып, сыныпта тәжірибе жасайды'},
    {en:'The teacher does not attend lessons',ru:'Учитель не приходит на уроки',kk:'Мұғалім сабаққа қатыспайды'},
    {en:'All learning takes place outdoors',ru:'Всё обучение проходит на улице',kk:'Барлық оқу далада өтеді'},
    {en:'Students only complete paper tests',ru:'Ученики выполняют только бумажные тесты',kk:'Оқушылар тек қағаз тесттерін орындайды'}],answer:0,
    why:{en:'Students prepare online before class; lesson time is used for discussion and practice.',ru:'Ученики готовятся онлайн до урока, а время в классе используют для обсуждения и практики.',kk:'Оқушылар сабаққа дейін онлайн дайындалып, сыныпта талқылау мен тәжірибе жасайды.'}},
  { q:{en:'Which is a key benefit of online learning materials?',ru:'Какое главное преимущество онлайн-материалов?',kk:'Онлайн материалдардың негізгі артықшылығы қандай?'}, options:[
    {en:'They remove the need for teachers',ru:'Они устраняют необходимость в учителях',kk:'Олар мұғалімнің қажеттілігін жояды'},
    {en:'They always guarantee higher marks',ru:'Они всегда гарантируют высокие оценки',kk:'Олар әрқашан жоғары бағаға кепілдік береді'},
    {en:'Students can pause, repeat and review them',ru:'Их можно останавливать, повторять и пересматривать',kk:'Оларды тоқтатып, қайталап, қайта қарауға болады'},
    {en:'They work without electricity or internet',ru:'Они работают без электричества и интернета',kk:'Олар электр мен интернетсіз жұмыс істейді'}],answer:2,
    why:{en:'Digital resources can support flexible revision, but they do not replace teacher guidance.',ru:'Цифровые ресурсы помогают повторять материал в удобном темпе, но не заменяют поддержку учителя.',kk:'Цифрлық ресурстар материалды икемді қайталауға көмектеседі, бірақ мұғалімнің қолдауын алмастырмайды.'}},
  { q:{en:'What is a common challenge of blended learning?',ru:'Какая распространённая трудность смешанного обучения?',kk:'Аралас оқытудың жиі кездесетін қиындығы қандай?'}, options:[
    {en:'No need to plan lessons',ru:'Не нужно планировать уроки',kk:'Сабақты жоспарлаудың қажеті жоқ'},
    {en:'Unequal access to devices and stable internet',ru:'Неравный доступ к устройствам и стабильному интернету',kk:'Құрылғылар мен тұрақты интернетке қолжетімділіктің әртүрлі болуы'},
    {en:'Teachers cannot communicate with students',ru:'Учителя не могут общаться с учениками',kk:'Мұғалімдер оқушылармен сөйлесе алмайды'},
    {en:'Students never work independently',ru:'Ученики никогда не работают самостоятельно',kk:'Оқушылар ешқашан өздігінен жұмыс істемейді'}],answer:1,
    why:{en:'Access to technology and connectivity must be considered when planning learning.',ru:'При планировании обучения важно учитывать доступ к технике и интернету.',kk:'Оқытуды жоспарлағанда техника мен интернетке қолжетімділікті ескеру қажет.'}},
  { q:{en:'What is the teacher’s role in blended learning?',ru:'Какова роль учителя в смешанном обучении?',kk:'Аралас оқытудағы мұғалімнің рөлі қандай?'}, options:[
    {en:'To guide, support and organize learning',ru:'Направлять, поддерживать и организовывать обучение',kk:'Оқытуды бағыттау, қолдау және ұйымдастыру'},
    {en:'To be replaced by an app',ru:'Быть заменённым приложением',kk:'Қосымшамен алмастырылу'},
    {en:'To assign online tasks only',ru:'Только задавать онлайн-задания',kk:'Тек онлайн тапсырмалар беру'},
    {en:'To avoid feedback',ru:'Избегать обратной связи',kk:'Кері байланыстан бас тарту'}],answer:0,
    why:{en:'The teacher designs the learning experience and provides feedback in both environments.',ru:'Учитель проектирует учебный процесс и даёт обратную связь в обоих форматах.',kk:'Мұғалім оқу үдерісін жоспарлап, екі ортада да кері байланыс береді.'}},
]
function QuizPage(){
 const {t,tl,lang}=useI18n(); const [answers,setAnswers]=React.useState<Record<number,number>>({}); const [checked,setChecked]=React.useState(false)
 const score=QUESTIONS.filter((q,i)=>answers[i]===q.answer).length
 return <><PageHero icon={Brain} eyebrow={t('common.shortTitle')} title={lang==='ru'?'Проверь знания':lang==='kk'?'Біліміңді тексер':'Knowledge Check'} subtitle={lang==='ru'?'Короткий тест по основным понятиям смешанного обучения.':lang==='kk'?'Аралас оқытудың негізгі ұғымдары бойынша қысқа тест.':'A short quiz on the key ideas of blended learning.'}/>
 <section className="mx-auto max-w-3xl space-y-5 px-4 py-12 sm:px-6">{QUESTIONS.map((q,i)=><article key={i} className="rounded-2xl border bg-card p-5"><h2 className="font-semibold">{i+1}. {tl(q.q)}</h2><div className="mt-4 grid gap-2">{q.options.map((o,j)=><label key={j} className={cn('flex cursor-pointer items-start gap-3 rounded-xl border p-3 text-sm transition-colors',answers[i]===j&&'border-primary bg-accent',checked&&j===q.answer&&'border-emerald-500 bg-emerald-500/10',checked&&answers[i]===j&&j!==q.answer&&'border-destructive bg-destructive/10')}><input type="radio" name={`q${i}`} checked={answers[i]===j} disabled={checked} onChange={()=>setAnswers(p=>({...p,[i]:j}))}/><span>{tl(o)}</span></label>)}</div>{checked&&<p className="mt-3 text-sm text-muted-foreground">{answers[i]===q.answer?'✓ ': '✗ '}{tl(q.why)}</p>}</article>)}
 <div className="flex flex-wrap items-center gap-3"><Button disabled={Object.keys(answers).length!==QUESTIONS.length||checked} onClick={()=>setChecked(true)}>{lang==='ru'?'Проверить':lang==='kk'?'Тексеру':'Check answers'}</Button><Button variant="outline" onClick={()=>{setAnswers({});setChecked(false)}}><RotateCcw className="mr-2 size-4"/>{t('common.reset')}</Button>{checked&&<p className="font-semibold"><Trophy className="mr-2 inline size-5 text-amber-500"/>{lang==='ru'?'Результат':lang==='kk'?'Нәтиже':'Score'}: {score}/{QUESTIONS.length}</p>}</div>
 </section></>
}
